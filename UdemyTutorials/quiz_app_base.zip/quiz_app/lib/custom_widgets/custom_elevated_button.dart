import 'package:flutter/material.dart';

class CustomElevatedButton extends StatelessWidget {
  final String text;
  final Color backgroundColor;
  final double fontSize;
  final Color textColor;
  final Function() onPressed;

  const CustomElevatedButton(this.text, this.backgroundColor, this.fontSize,
      this.textColor, this.onPressed,
      {super.key});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
        style: ElevatedButton.styleFrom(
            backgroundColor: backgroundColor,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(45))),
        onPressed: onPressed,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(15, 15, 10, 15),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: fontSize, color: textColor, fontWeight: FontWeight.w900),
          ),
        ));
  }
}
