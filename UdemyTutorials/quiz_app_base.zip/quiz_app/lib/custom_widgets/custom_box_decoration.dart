
import 'package:flutter/material.dart';

class CustomBoxDecoration extends StatelessWidget {

  final Widget? childWidget;
  final List<Color> colors;

  const CustomBoxDecoration(this.colors, {super.key, required this.childWidget});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          end: Alignment.bottomCenter,
          begin: Alignment.topCenter,
          colors: colors,
        ),
      ),
      child: childWidget,
    );
  }
}