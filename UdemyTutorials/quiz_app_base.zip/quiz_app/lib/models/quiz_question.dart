
class QuizQuestion {
  final String question;
  final List<String> answerList;

  const QuizQuestion(this.question, this.answerList);

  List<String> getShuffledAnswerList() {
    List<String> list = List.of(answerList);
    list.shuffle();
    return list;
  }
}