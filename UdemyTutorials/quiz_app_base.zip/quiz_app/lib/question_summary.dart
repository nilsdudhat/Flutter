import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class QuestionSummary extends StatelessWidget {
  final List<Map<String, Object>> summaryList;

  const QuestionSummary(this.summaryList, {super.key});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: SingleChildScrollView(
        child: Column(
          children: summaryList.map((data) {
            return Column(
              children: [
                Container(
                  height: 1,
                  color: Colors.white54,
                ),
                const SizedBox(
                  height: 10,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CircleAvatar(
                      backgroundColor: data["correct-answer"].toString() ==
                              data["selected-answer"].toString()
                          ? Colors.greenAccent
                          : Colors.redAccent,
                      child: Text(
                        ((data["question-index"] as int) + 1).toString(),
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 10,
                          ),
                          Text(
                            data["question"] as String,
                            style: GoogleFonts.josefinSans(
                                fontSize: 20,
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Text(
                            "Selected Answer: ${data["selected-answer"]}",
                            style: TextStyle(
                                fontSize: 15,
                                color: data["correct-answer"].toString() ==
                                        data["selected-answer"].toString()
                                    ? Colors.greenAccent
                                    : Colors.redAccent,
                                fontWeight: FontWeight.bold),
                            textAlign: TextAlign.start,
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Text(
                            "Correct Answer: ${data["correct-answer"]}",
                            style: const TextStyle(
                                fontSize: 15,
                                color: Colors.greenAccent,
                                fontWeight: FontWeight.bold),
                            textAlign: TextAlign.start,
                          ),
                          const SizedBox(
                            height: 25,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }
}
