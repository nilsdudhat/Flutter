import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:quiz_app/data/questions.dart';
import 'package:quiz_app/models/quiz_question.dart';
import 'package:quiz_app/question_summary.dart';

class ResultScreen extends StatelessWidget {
  final List<String> selectedAnswers;
  final void Function() restartQuiz;
  final List<QuizQuestion> tempQuestionList = questionList;

  const ResultScreen(
      {super.key, required this.selectedAnswers, required this.restartQuiz});

  List<Map<String, Object>> getSummaryList() {
    List<Map<String, Object>> summaryList = [];

    for (var i = 0; i < selectedAnswers.length; i++) {
      summaryList.add({
        "question-index": i,
        "question": tempQuestionList[i].question,
        "selected-answer": selectedAnswers[i],
        "correct-answer": tempQuestionList[i].answerList[0]
      });
    }

    return summaryList;
  }

  @override
  Widget build(BuildContext context) {
    List<Map<String, Object>> summaryList = getSummaryList();

    int listLength = tempQuestionList.length;
    var correctAnswerCount = summaryList.where((data) {
      return data["selected-answer"] == data["correct-answer"];
    }).length;

    /*for (var i = 0; i < tempQuestionList.length; i++) {
      QuizQuestion quizQuestion = tempQuestionList[i];

      List<String> answerList = quizQuestion.answerList;
      if (selectedAnswers[i] == answerList[0]) {
        correctAnswerCount++;
      }
    }*/

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(100),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'You answered $correctAnswerCount out of $listLength questions correctly!',
              textAlign: TextAlign.center,
              style: GoogleFonts.josefinSans(
                  fontSize: 25,
                  color: Colors.white,
                  fontWeight: FontWeight.bold),
            ),
            const SizedBox(
              height: 50,
            ),
            QuestionSummary(summaryList),
            const SizedBox(
              height: 50,
            ),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white // text and icon color
                  ),
              onPressed: restartQuiz,
              icon: const Icon(
                Icons.restart_alt,
              ),
              label: const Text(
                'Restart Quiz',
                style: TextStyle(color: Colors.white, fontSize: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
