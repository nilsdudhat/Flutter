import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:quiz_app/custom_widgets/custom_elevated_button.dart';
import 'package:quiz_app/data/questions.dart';

class QuestionScreen extends StatefulWidget {
  final void Function(String answer) addAnswer;

  const QuestionScreen({
    super.key,
    required this.addAnswer,
  });

  @override
  State<QuestionScreen> createState() => _QuestionScreenState();
}

class _QuestionScreenState extends State<QuestionScreen> {
  var currentIndex = 0;

  void updateAnswer(String selectedAnswer) {
    widget.addAnswer(selectedAnswer);

    setState(() {
      currentIndex++;
    });
  }

  @override
  Widget build(BuildContext context) {
    var currentQuestion = questionList[currentIndex];

    return Center(
      child: Container(
        margin: const EdgeInsets.all(40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              currentQuestion.question,
              style: GoogleFonts.josefinSans(
                  fontSize: 25,
                  color: Colors.white,
                  fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 25,
            ),
            ...currentQuestion.getShuffledAnswerList().map((answer) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 20),
                child: CustomElevatedButton(
                    answer, Colors.white, 18, Colors.black, () {
                  updateAnswer(answer);
                }),
              );
            }),
          ],
        ),
      ),
    );
  }
}
