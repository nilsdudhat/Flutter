
import 'package:flutter/material.dart';
import 'package:quiz_app/custom_widgets/custom_box_decoration.dart';
import 'package:quiz_app/data/questions.dart';
import 'package:quiz_app/question_screen.dart';
import 'package:quiz_app/reslt_screen.dart';
import 'package:quiz_app/start_screen.dart';

class Quiz extends StatefulWidget {
  const Quiz({super.key});

  @override
  State<Quiz> createState() => _QuizState();
}

class _QuizState extends State<Quiz> {
  var activeScreen = "start-screen";
  List<String> selectedAnswers = [];

  void addAnswer(String answer) {
    selectedAnswers.add(answer);

    if (selectedAnswers.length == questionList.length) {
      setState(() {
        activeScreen = "result-screen";
      });
    }
  }

  void restartQuiz() {
    selectedAnswers = [];

    setState(() {
      activeScreen = "start-screen";
    });
  }

  void switchScreen() {
    setState(() {
      activeScreen = "question-screen";
    });
  }

  @override
  Widget build(context) {
    Widget displayWidget = StartScreen(switchScreen);

    if (activeScreen == "start-screen") {
      displayWidget = StartScreen(switchScreen);
    } else if (activeScreen == "question-screen") {
      displayWidget = QuestionScreen(addAnswer: addAnswer);
    } else if (activeScreen == "result-screen") {
      displayWidget = ResultScreen(
          selectedAnswers: selectedAnswers, restartQuiz: restartQuiz);
    }

    return MaterialApp(
      home: Scaffold(
        body: CustomBoxDecoration(
          const [
            Colors.deepPurple,
            Colors.deepPurpleAccent,
          ],
          childWidget: displayWidget,
        ),
      ),
    );
  }
}
